package activida5;
 
public class Velocista extends Relevista {
	private double tiempoPromedio;
	private double velocidadPromedio;
	public Velocista(int identificador, String nombreRelevista, double tiempoAcumuladoCarrera,double tiempoPromedio,double velocidadPromedio) {
		super(identificador, nombreRelevista, tiempoAcumuladoCarrera);
		this.tiempoPromedio= tiempoPromedio;
		this.velocidadPromedio=velocidadPromedio;
	}

	@Override
	public String ImprimirTipo() {
		return "Es velocista" ;
	}

	@Override
	public double calcularMarca() {
		return tiempoPromedio * 10;
	}

	public double getTiempoPromedio() {
		return tiempoPromedio;
	}

	public void setTiempoPromedio(double tiempoPromedio) {
		this.tiempoPromedio = tiempoPromedio;
	}

	public double getVelocidadPromedio() {
		return velocidadPromedio;
	}

	public void setVelocidadPromedio(double velocidadPromedio) {
		this.velocidadPromedio = velocidadPromedio;
	}

	 
 }

