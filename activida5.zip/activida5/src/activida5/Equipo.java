package activida5;

	public class Equipo implements calculable {
	    private static int contadorIds = 1;
	    private int id;
	    private String nombre;
	    private String pais;
	    private double tiempoTotal;
	    private Relevista rel1, rel2, rel3;

	    public Equipo(String nombre, String pais) {
	        this.id = contadorIds++;
	        this.nombre = nombre;
	        this.pais = pais;
	        this.tiempoTotal = 0;
	        this.rel1 =  null;
	        this.rel2 = null;
	        this.rel3 = null;
	    }

	    public Equipo(String nombre, String pais, Relevista r1, Relevista r2, Relevista r3) {
	        this(nombre, pais);
	        this.rel1 = r1;
	        this.rel2 = r2;
	        this.rel3 = r3;
	        this.tiempoTotal = calculaTiempoTotal();
	    }
	    public int getId() { return id; }
	    public String getNombre() { return nombre; }
	    public String getPais() { return pais; }
	    public double getTiempoTotal() { return tiempoTotal; }
	    public Relevista getRel1() { return rel1; }
	    public Relevista getRel2() { return rel2; }
	    public Relevista getRel3() { return rel3; }

	    public void setRel1(Relevista r) { this.rel1 = r; }
	    public void setRel2(Relevista r) { this.rel2 = r; }
	    public void setRel3(Relevista r) { this.rel3 = r; }

	    public   String imprimir() {
	        return "Nombre: " + nombre + ", tiempo total: " + tiempoTotal + ", datos relevistas:\n" 
	            + "(rev1: " + rel1.imprir() + ")\n" 
	        	+ "(rev2: " + rel2.imprir() + ")\n"
	            + "(rev3: " + rel3.imprir() + ")";
	    }

	    public String mostrarRelevistas() {
	        return "rev1: " + rel1.getNombreRelevista() + ", rev2: " + rel2.getNombreRelevista() + ", rev3: " + rel3.getNombreRelevista();
	    }

	    public Relevista datosRelevista(int id) {
	        if (rel1 != null && rel1.getIdentificador() == id) return rel1;
	        if (rel2 != null && rel2.getIdentificador() == id) return rel2;
	        if (rel3 != null && rel3.getIdentificador() == id) return rel3;
	        return null;
	    }

		@Override
		public double calculaTiempoTotal() {
			 double total = 0;
		        if (rel1 != null) total += rel1.getTiempoAcumuladoCarrera();
		        if (rel2 != null) total += rel2.getTiempoAcumuladoCarrera();
		        if (rel3 != null) total += rel3.getTiempoAcumuladoCarrera();
		        return total;
		}

		@Override
		public double calculaMedia() {
			 int count = 0;
		        double total = 0;
		        if (rel1 != null) { total += rel1.getTiempoAcumuladoCarrera(); count++; }
		        if (rel2 != null) { total += rel2.getTiempoAcumuladoCarrera(); count++; }
		        if (rel3 != null) { total += rel3.getTiempoAcumuladoCarrera(); count++; }
		      
		        return (count > 0) ? total / count : 0;
		}
	     
	}

