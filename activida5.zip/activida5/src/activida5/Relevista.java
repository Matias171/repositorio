package activida5;

public abstract class Relevista {
	private int identificador;
	private String nombreRelevista ;
	private  double tiempoAcumuladoCarrera = 0;
	 
	public Relevista(int identificador, String nombreRelevista, double tiempoAcumuladoCarrera) {
		super();
		this.identificador = identificador;
		this.nombreRelevista = nombreRelevista;
		this.tiempoAcumuladoCarrera =tiempoAcumuladoCarrera; 
	}
	public Relevista(int identificador, String nombreRelevista) {
		super();
		this.identificador = identificador;
		this.nombreRelevista = nombreRelevista;
		this.tiempoAcumuladoCarrera =0.0; 
	}
	public abstract String ImprimirTipo ();
	public abstract double calcularMarca();
	public String imprir() {
		return "El relevista llamado "+nombreRelevista +"con el identificador "+identificador+"tiene un tiempo acumulado de "+tiempoAcumuladoCarrera;
	}
	public double getTiempoAcumuladoCarrera() {
		return tiempoAcumuladoCarrera;
	}
	public void setTiempoAcumuladoCarrera(double tiempoAcumuladoCarrera) {
		this.tiempoAcumuladoCarrera = tiempoAcumuladoCarrera;
	}
	public int getIdentificador() {
		return identificador;
	}
	public void setIdentificador(int identificador) {
		this.identificador = identificador;
	}
	public String getNombreRelevista() {
		return nombreRelevista;
	}
	public void setNombreRelevista(String nombreRelevista) {
		this.nombreRelevista = nombreRelevista;
	}

}
