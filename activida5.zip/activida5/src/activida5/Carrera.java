package activida5;

//Carrera.java
public class Carrera {
 private Equipo[] equipos;
 private int index;

 public Carrera() {
     equipos = new Equipo[2];
     index = 0;
 }

 public void agregarEquipo(Equipo e) {
     if (index < equipos.length) {
         equipos[index++] = e;
     } else {
         System.out.println("No se pueden agregar más equipos.");
     }
 }

 public void mostrarEquipos() {
     for (int i = 0; i < index; i++) {
         if (equipos[i] != null) {
             System.out.println(equipos[i].imprimir());
         }
     }
 }

 public Equipo buscarEquipo(int id) {
     for (int i = 0; i < index; i++) {
         if (equipos[i] != null && equipos[i].getId() == id) {
             return equipos[i];
         }
     }
     return null;
 }
}
 
