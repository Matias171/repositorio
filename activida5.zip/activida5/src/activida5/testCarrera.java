package activida5; 
import java.util.Scanner;
public class testCarrera {
    public static void main(String[] args) {
        Carrera carrera = new Carrera();
        Relevista r1 = new Velocista(1, "velocista1", 100, 25, 55.5);
        Relevista r2 = new Mediofondista(2, "mediofond22", 120, 85.27f);
        r2.setTiempoAcumuladoCarrera(120);
        Relevista r3 = new Sprinter(3, "srpintXX3", 80, 45.50);
        r3.setTiempoAcumuladoCarrera(80);
        Equipo equipo1 = new Equipo("VallecasRel", "Espanya", r1, r2, r3);

        Relevista r4 = new Velocista(10, "velocista10", 85, 18, 58.5);
        r4.setTiempoAcumuladoCarrera(85);
        Relevista r5 = new Velocista(20, "otroveld220", 90, 17, 61.5);
        r5.setTiempoAcumuladoCarrera(90);
        Relevista r6 = new Sprinter(30, "srpintXX0", 75, 48.5);
        r6.setTiempoAcumuladoCarrera(75);
        Equipo equipo2 = new Equipo("SanSebastianRel", "Espanya", r4, r5, r6);

        carrera.agregarEquipo(equipo1);
        carrera.agregarEquipo(equipo2);

        carrera.mostrarEquipos();             

        System.out.println("\n***** NOMBRES RELEVISTAS EQUIPO1 ******");
        System.out.println(equipo1.mostrarRelevistas());
        System.out.println("***** NOMBRES RELEVISTAS EQUIPO2 ******");
        System.out.println(equipo2.mostrarRelevistas());

        System.out.println("\n***** TIEMPO TOTAL EQUIPO1 ******");
        System.out.println("TiempoTotal " + equipo1.calculaTiempoTotal());
        System.out.println("***** TIEMPO TOTAL EQUIPO2 ******");
        System.out.println("TiempoTotal " + equipo2.calculaTiempoTotal());

        System.out.println("\n***** TIEMPO MEDIO EQUIPO1 ******");
        System.out.println("Tiempo medio " + equipo1.calculaMedia());
        System.out.println("***** TIEMPO MEDIO EQUIPO2 ******");
        System.out.println("Tiempo medio " + equipo2.calculaMedia());

        Scanner scanner = new Scanner(System.in);
        System.out.println("\n***** DEVOLVER DATOS RELEVISTA ******");
        System.out.println("Dame el equipo (id)");
        int idEquipo = scanner.nextInt();
        Equipo equipoBuscado = carrera.buscarEquipo(idEquipo);

        if (equipoBuscado != null) {
            System.out.println("Dame un id de un relevista de ese equipo y te muestro sus datos:");
            int idRelevista = scanner.nextInt();
            Relevista rev = equipoBuscado.datosRelevista(idRelevista);
            if (rev != null) {
                System.out.println("Datos del relevista con id " + idRelevista + ": " + rev.imprir());
            } else {
                System.out.println("No se encontró relevista con ese id.");
            }
        }

        System.out.println("\n***** IMPRIMIR TIPOS RELEVISTAS EQUIPO1 ******");
        System.out.println("rev1 " + equipo1.getRel1().ImprimirTipo());
        System.out.println("rev2 " + equipo1.getRel2().ImprimirTipo());
        System.out.println("rev3 " + equipo1.getRel3().ImprimirTipo());

        System.out.println("***** IMPRIMIR TIPOS RELEVISTAS EQUIPO2 ******");
        System.out.println("rev1 " + equipo2.getRel1().ImprimirTipo());
        System.out.println("rev2 " + equipo2.getRel2().ImprimirTipo());
        System.out.println("rev3 " + equipo2.getRel3().ImprimirTipo());

        System.out.println("\n***** MARCA RELEVISTA 1 EQUIPO 1 ******");
        System.out.println("La marca del relevista 1 es " + equipo1.getRel1().calcularMarca());
    }
}

