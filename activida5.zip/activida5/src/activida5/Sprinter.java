package activida5;

public class Sprinter extends Relevista {
	private double velocidadMaxima;
	public Sprinter(int identificador, String nombreRelevista, double tiempoAcumuladoCarrera,double velocidadMaxima) {
		super(identificador, nombreRelevista, tiempoAcumuladoCarrera);
		this.velocidadMaxima=velocidadMaxima;
	}

	@Override
	public String ImprimirTipo() {
		return "Es un sprinter" ;
	}

	@Override
	public double calcularMarca() {
		return getTiempoAcumuladoCarrera() * velocidadMaxima;
	}

	public double getVelocidadMaxima() {
		return velocidadMaxima;
	}

	public void setVelocidadMaxima(double velocidadMaxima) {
		this.velocidadMaxima = velocidadMaxima;
	}

}