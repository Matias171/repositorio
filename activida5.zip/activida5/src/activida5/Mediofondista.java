package activida5; 

public class Mediofondista extends Relevista {
	private float aceleracioPromedio;

	public Mediofondista(int identificador, String nombreRelevista, double tiempoAcumuladoCarrera,float aceleracioPromedio) {
		super(identificador, nombreRelevista, tiempoAcumuladoCarrera);
	this.aceleracioPromedio=aceleracioPromedio;
	}

	@Override
	public String ImprimirTipo() {
		// TODO Auto-generated method stub
		return "Es mediofondista";
	}

	@Override
	public double calcularMarca() {
		return getTiempoAcumuladoCarrera() * aceleracioPromedio  ;
	}

	public float getAceleracioPromedio() {
		return aceleracioPromedio;
	}

	public void setAceleracioPromedio(float aceleracioPromedio) {
		this.aceleracioPromedio = aceleracioPromedio;
	}

}
