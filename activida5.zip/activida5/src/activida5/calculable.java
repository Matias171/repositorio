package activida5;

public interface  calculable {
	 double calculaTiempoTotal();
	 double calculaMedia();
}
 
